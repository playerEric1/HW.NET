namespace CSharpDay7;

public abstract class Entity
{
    public int Id { get; set; }
}