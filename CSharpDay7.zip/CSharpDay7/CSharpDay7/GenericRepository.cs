namespace CSharpDay7;

public class GenericRepository<T>: IRepository<T> where T: Entity
{
    private readonly List<T> items;

    public GenericRepository()
    {
        items = new List<T>();
    }

    public void Add(T item)
    {
        items.Add(item);
    }

    public void Remove(T item)
    {
        items.Remove(item);
    }

    public void Save()
    {

    }

    public IEnumerable<T> GetAll()
    {
        return items.AsReadOnly();
    }

    public T GetById(int id)
    {
        return items.FirstOrDefault(item => item.Id == id);
    }
}