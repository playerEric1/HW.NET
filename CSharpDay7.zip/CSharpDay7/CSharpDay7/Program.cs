﻿namespace CSharpDay7;

class Program
{
    static void Main(string[] args)
    {
        MyStack<int> myStack = new MyStack<int>();
        myStack.Push(1);
        myStack.Push(3);
        myStack.Push(0);
        myStack.Push(2);
        Console.WriteLine("Size of stack: " + myStack.Count());
        Console.WriteLine("Pop: " + myStack.Pop());
        Console.WriteLine("Size of stack: " + myStack.Count());
        Console.WriteLine();

        MyList<int> myList = new MyList<int>();
        myList.Add(1);
        myList.Add(2);
        myList.Add(3);
        Console.WriteLine(myList.Find(1));
        myList.InsertAt(5, 1);
        Console.WriteLine(myList.Find(1));
        myList.DeleteAt(2);
        Console.WriteLine(myList.Find(2));
        Console.WriteLine(myList.Contains(1));
        myList.Remove(0);
        Console.WriteLine(myList.Find(0));
        myList.Clear();
        Console.WriteLine(myList.Contains(1));
        Console.WriteLine();

        IRepository<Person> personRepo = new GenericRepository<Person>();
        personRepo.Add(new Person { Id = 1, Name = "David" });
        personRepo.Add(new Person { Id = 2, Name = "John" });
        var personById = personRepo.GetById(1);
        Console.WriteLine(personById.Name);
        IEnumerable<Person> all = personRepo.GetAll();
        foreach (Person person in all)
        {
            Console.WriteLine($"ID: {person.Id}, Name: {person.Name}");
        }
    }
}

internal class Person : Entity
{
    public string Name { get; set; }
}