namespace CSharpDay7;

public class MyStack<T>
{
    private readonly int max = 1024;
    private T[] array;
    private int size;

    public MyStack()
    {
        array = new T[max];
        size = 0;
    }

    public int Count()
    {
        return size;
    }

    public T Pop()
    {
        if (size == 0)
        {
            Console.WriteLine("Stack underflow");
            return default;
        }
        return array[--size];
    }

    public void Push(T input)
    {
        if (size >= max)
        {
            Console.WriteLine("Stack overflow");
        }
        else
        {
            array[size++] = input;
        }
    }
}