﻿namespace CSharpDay6;

class Program
{
    static void Main(string[] args)
    {
        int[] numbers = GenerateNumbers();
        Reverse(numbers);
        PrintNumbers(numbers);
    }

    private static void PrintNumbers(int[] numbers)
    {
        foreach (int num in numbers)
        {
            Console.Write(num + " ");
        }
    }

    private static void Reverse(int[] numbers)
    {
        int length = numbers.Length;
        for (int i = 0; i < length / 2; i++)
        {
            int temp = numbers[i];
            numbers[i] = numbers[length - i - 1];
            numbers[length - i - 1] = temp;
        }
    }

    private static int[] GenerateNumbers(int length = 10)
    {
        int[] numbers = new int[length];
        for (int i = 0; i < length; i++)
        {
            numbers[i] = i + 1;
        }
        return numbers;
    }
}