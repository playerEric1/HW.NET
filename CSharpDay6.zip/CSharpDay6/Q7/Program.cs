﻿namespace Q2;

class Program
{
    static void Main(string[] args)
    {
        Color red = new Color(255, 0, 0);
        Color green = new Color(0, 255, 0);
        Color blue = new Color(0, 0, 255);
        Color white = new Color(255, 255, 255);
        Ball ball1 = new Ball(1, red);
        Ball ball2 = new Ball(5, green);
        Ball ball3 = new Ball(2, blue);
        Ball ball4 = new Ball(3, white);

        ball1.Throw();
        ball1.Throw();
        ball2.Throw();
        ball3.Throw();
        ball3.Throw();
        ball3.Pop();
        ball3.Throw();
        ball3.Throw();
        ball3.Throw();
        ball4.Throw();

        Console.WriteLine($"Ball1 throw count: {ball1.GetThrowCount()}");
        Console.WriteLine($"Ball2 throw count: {ball2.GetThrowCount()}");
        Console.WriteLine($"Ball3 throw count: {ball3.GetThrowCount()}");
        Console.WriteLine($"Ball4 throw count: {ball4.GetThrowCount()}");
    }
}