using Q1.Interfaces;

namespace Q1.Models;

// abstraction
public abstract class Person : IPersonService
{
    // encapsulation
    public string Name { get; set; }
    public DateTime DateOfBirth { get; set; }
    private decimal salary;
    private List<string> Addresses { get; set; }

    public decimal Salary
    {
        get => salary;
        set
        {
            if (value < 0)
            {
                Console.WriteLine("Salary cannot be negative number.");
            }
            else
            {
                salary = value;
            }
        }
    }

    public Person(string name, DateTime dateOfBirth, decimal salary)
    {
        Name = name;
        DateOfBirth = dateOfBirth;
        Salary = salary;
        Addresses = new List<string>();
    }

    public int CalculateAge()
    {
        DateTime today = DateTime.Today;
        return today.Year - DateOfBirth.Year;
    }

    public virtual decimal CalculateSalary()
    {
        return Salary;
    }

    public List<string> GetAddresses()
    {
        return Addresses;
    }

    public void AddAddress(string address)
    {
        Addresses.Add(address);
    }

    public abstract void DisplayInfo();
}