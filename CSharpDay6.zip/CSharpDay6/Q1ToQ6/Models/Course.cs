using Q1.Interfaces;

namespace Q1.Models;

public class Course : ICourseService
{
    public string CourseName { get; set; }
    public List<Student> EnrolledStudents { get; set; }

    public Course(string courseName)
    {
        CourseName = courseName;
        EnrolledStudents = new List<Student>();
    }

    public List<Student> GetEnrolledStudents()
    {
        return EnrolledStudents;
    }
}