using Q1.Interfaces;

namespace Q1.Models;

public class Department : IDepartmentService
{
    public string Name { get; set; }
    public Instructor Head { get; private set; }
    public decimal Budget { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    private List<Course> Courses { get; set; }

    public Department(string name, decimal budget, DateTime startDate, DateTime endDate)
    {
        Name = name;
        Budget = budget;
        StartDate = startDate;
        EndDate = endDate;
        Courses = new List<Course>();
    }

    public void SetHead(Instructor instructor)
    {
        Head = instructor;
    }

    public void AddCourse(Course course)
    {
        Courses.Add(course);
    }

    public List<Course> GetCourses()
    {
        return Courses;
    }
}