using Q1.Interfaces;

namespace Q1.Models;

// inheritance
public class Instructor : Person, IInstructorService
{
    // encapsulation
    private string Department { get; set; }
    private DateTime JoinDate { get; set; }
    public bool IsHead { get; set; }

    public Instructor(string name, DateTime dateOfBirth, decimal salary, string department, DateTime joinDate)
        : base(name, dateOfBirth, salary)
    {
        Department = department;
        JoinDate = joinDate;
    }

    // Polymorphism
    public override void DisplayInfo()
    {
        Console.WriteLine($"Instructor: {Name}, Age: {CalculateAge()}, Department: {Department}, Salary: {CalculateSalary()}, Years of Experience: {CalculateExperience()}");
    }

    public void SetDepartment(Department department)
    {
        Department = department.Name;
        IsHead = department.Head == this;
    }

    // polymorphism
    public override decimal CalculateSalary()
    {
        return Salary + Salary * 0.1m * CalculateExperience();
    }

    private int CalculateExperience()
    {
        DateTime today = DateTime.Today;
        return today.Year - JoinDate.Year;
    }
}