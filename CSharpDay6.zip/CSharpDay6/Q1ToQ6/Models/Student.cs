using Q1.Interfaces;

namespace Q1.Models;

// inheritance
public class Student : Person, IStudentService
{
    // encapsulation
    private string StudentID { get; set; }
    private string Major { get; set; }
    private List<Course> Courses { get; set; }
    private Dictionary<Course, char> Grades { get; set; }

    public Student(string name, DateTime dateOfBirth, decimal salary, string studentID, string major)
        : base(name, dateOfBirth, salary)
    {
        StudentID = studentID;
        Major = major;
        Courses = new List<Course>();
        Grades = new Dictionary<Course, char>();
    }

    // polymorphism
    public override void DisplayInfo()
    {
        Console.WriteLine($"Student: {Name}, Age: {CalculateAge()}, Student ID: {StudentID}, Major: {Major}");
    }

    public void AddCourse(Course course)
    {
        Courses.Add(course);
        course.EnrolledStudents.Add(this);
    }

    public void AssignGrade(Course course, char grade)
    {
        if (Courses.Contains(course))
        {
            Grades[course] = grade;
        }
    }

    public decimal CalculateGPA()
    {
        decimal totalPoints = 0;
        foreach (var grade in Grades.Values)
        {
            totalPoints += GradeToGPA(grade);
        }
        return totalPoints / Grades.Count;;
    }

    private decimal GradeToGPA(char grade)
    {
        return grade switch
        {
            'A' => 4.0m,
            'B' => 3.5m,
            'C' => 3.0m,
            'D' => 2.0m,
            'E' => 1.0m,
            _ => 0.0m,
        };
    }
}