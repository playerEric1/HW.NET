﻿using Q1.Models;

namespace Q1;

class Program
{
    static void Main(string[] args)
    {
        Course course1 = new Course("CS101");
        Course course2 = new Course("MATH101");

        Department csDepartment = new Department("Computer Science", 1000000m, new DateTime(2023, 1, 1),
            new DateTime(2023, 12, 31));
        csDepartment.AddCourse(course1);
        csDepartment.AddCourse(course2);

        Student student = new Student("Peter", new DateTime(2000, 1, 1), 0m, "U12345", "Computer Science");
        student.AddCourse(course1);
        student.AssignGrade(course1, 'A');
        student.AddCourse(course2);
        student.AssignGrade(course2, 'B');

        Instructor instructor = new Instructor("Smith", new DateTime(1970, 1, 1), 50000m, "Computer Science",
            new DateTime(2000, 1, 15));
        csDepartment.SetHead(instructor);
        student.AddAddress("1 North St");
        instructor.AddAddress("2 University Ave");

        student.DisplayInfo();
        Console.WriteLine($"Student GPA: {student.CalculateGPA()}");
        instructor.DisplayInfo();
        Console.WriteLine($"Instructor Salary: {instructor.CalculateSalary()}");
        Console.WriteLine($"Department: {csDepartment.Name}, Head: {csDepartment.Head.Name}");

        Console.Write($"Enrolled students in {course1.CourseName}: ");
        foreach (var enrolledStudent in course1.GetEnrolledStudents())
        {
            Console.Write(enrolledStudent.Name);
        }
    }
}
