using Q1.Models;

namespace Q1.Interfaces;

public interface IPersonService
{
    int CalculateAge();
    decimal CalculateSalary();
    List<string> GetAddresses();
}

public interface IStudentService : IPersonService
{
    void AddCourse(Course course);
    decimal CalculateGPA();
}

public interface IInstructorService : IPersonService
{
    void SetDepartment(Department department);
}

public interface ICourseService;

public interface IDepartmentService
{
    void SetHead(Instructor instructor);
    void AddCourse(Course course);
}